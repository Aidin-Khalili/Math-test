﻿namespace HW2
{
    partial class FormMathGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Tested = new System.Windows.Forms.Label();
            this.lblTested = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.grpType = new System.Windows.Forms.GroupBox();
            this.chkAdd = new System.Windows.Forms.CheckBox();
            this.chkSubs = new System.Windows.Forms.CheckBox();
            this.chkMul = new System.Windows.Forms.CheckBox();
            this.chkDiv = new System.Windows.Forms.CheckBox();
            this.rdoFactorRandom = new System.Windows.Forms.RadioButton();
            this.rdoFactor0 = new System.Windows.Forms.RadioButton();
            this.rdoFactor2 = new System.Windows.Forms.RadioButton();
            this.rdoFactor1 = new System.Windows.Forms.RadioButton();
            this.rdoFactor3 = new System.Windows.Forms.RadioButton();
            this.rdoFactor4 = new System.Windows.Forms.RadioButton();
            this.btnStart = new System.Windows.Forms.Button();
            this.timerQuestion = new System.Windows.Forms.Timer(this.components);
            this.lblQuestion = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.grpTimer = new System.Windows.Forms.GroupBox();
            this.grpFactor = new System.Windows.Forms.GroupBox();
            this.rdoFactor5 = new System.Windows.Forms.RadioButton();
            this.rdoFactor6 = new System.Windows.Forms.RadioButton();
            this.rdoFactor7 = new System.Windows.Forms.RadioButton();
            this.rdoFactor9 = new System.Windows.Forms.RadioButton();
            this.rdoFactor8 = new System.Windows.Forms.RadioButton();
            this.rdoTimerOff = new System.Windows.Forms.RadioButton();
            this.rdoTimerForward = new System.Windows.Forms.RadioButton();
            this.rdoTimerBackward = new System.Windows.Forms.RadioButton();
            this.vsbTimer = new System.Windows.Forms.VScrollBar();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblTimer = new System.Windows.Forms.Label();
            this.lblCorrect = new System.Windows.Forms.Label();
            this.grpType.SuspendLayout();
            this.grpTimer.SuspendLayout();
            this.grpFactor.SuspendLayout();
            this.SuspendLayout();
            // 
            // Tested
            // 
            this.Tested.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Tested.Location = new System.Drawing.Point(130, 18);
            this.Tested.Name = "Tested";
            this.Tested.Size = new System.Drawing.Size(115, 30);
            this.Tested.TabIndex = 0;
            this.Tested.Text = "Tested:";
            // 
            // lblTested
            // 
            this.lblTested.BackColor = System.Drawing.Color.Red;
            this.lblTested.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTested.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblTested.ForeColor = System.Drawing.Color.Yellow;
            this.lblTested.Location = new System.Drawing.Point(260, 18);
            this.lblTested.Name = "lblTested";
            this.lblTested.Size = new System.Drawing.Size(115, 30);
            this.lblTested.TabIndex = 1;
            this.lblTested.Text = "0";
            this.lblTested.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(28, 242);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(765, 23);
            this.label5.TabIndex = 4;
            // 
            // grpType
            // 
            this.grpType.BackColor = System.Drawing.Color.RoyalBlue;
            this.grpType.Controls.Add(this.chkSubs);
            this.grpType.Controls.Add(this.chkMul);
            this.grpType.Controls.Add(this.chkDiv);
            this.grpType.Controls.Add(this.chkAdd);
            this.grpType.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.grpType.ForeColor = System.Drawing.Color.Black;
            this.grpType.Location = new System.Drawing.Point(38, 291);
            this.grpType.Name = "grpType";
            this.grpType.Size = new System.Drawing.Size(207, 178);
            this.grpType.TabIndex = 5;
            this.grpType.TabStop = false;
            this.grpType.Text = "Type of Question";
            this.grpType.Enter += new System.EventHandler(this.grpType_Enter);
            // 
            // chkAdd
            // 
            this.chkAdd.AutoSize = true;
            this.chkAdd.Checked = true;
            this.chkAdd.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkAdd.Location = new System.Drawing.Point(16, 33);
            this.chkAdd.Name = "chkAdd";
            this.chkAdd.Size = new System.Drawing.Size(130, 24);
            this.chkAdd.TabIndex = 6;
            this.chkAdd.Text = "Addition (+)";
            this.chkAdd.UseVisualStyleBackColor = true;
            this.chkAdd.CheckedChanged += new System.EventHandler(this.chkType_CheckedChanged);
            // 
            // chkSubs
            // 
            this.chkSubs.AutoSize = true;
            this.chkSubs.Location = new System.Drawing.Point(16, 65);
            this.chkSubs.Name = "chkSubs";
            this.chkSubs.Size = new System.Drawing.Size(164, 24);
            this.chkSubs.TabIndex = 0;
            this.chkSubs.Text = "Substraction (-)";
            this.chkSubs.UseVisualStyleBackColor = true;
            this.chkSubs.CheckedChanged += new System.EventHandler(this.chkType_CheckedChanged);
            // 
            // chkMul
            // 
            this.chkMul.AutoSize = true;
            this.chkMul.Location = new System.Drawing.Point(16, 99);
            this.chkMul.Name = "chkMul";
            this.chkMul.Size = new System.Drawing.Size(172, 24);
            this.chkMul.TabIndex = 1;
            this.chkMul.Text = "Multiplication (x)";
            this.chkMul.UseVisualStyleBackColor = true;
            this.chkMul.CheckedChanged += new System.EventHandler(this.chkType_CheckedChanged);
            // 
            // chkDiv
            // 
            this.chkDiv.AutoSize = true;
            this.chkDiv.Location = new System.Drawing.Point(16, 131);
            this.chkDiv.Name = "chkDiv";
            this.chkDiv.Size = new System.Drawing.Size(125, 24);
            this.chkDiv.TabIndex = 2;
            this.chkDiv.Text = "Division (/)";
            this.chkDiv.UseVisualStyleBackColor = true;
            this.chkDiv.CheckedChanged += new System.EventHandler(this.chkType_CheckedChanged);
            // 
            // rdoFactorRandom
            // 
            this.rdoFactorRandom.AutoSize = true;
            this.rdoFactorRandom.Checked = true;
            this.rdoFactorRandom.Location = new System.Drawing.Point(29, 34);
            this.rdoFactorRandom.Name = "rdoFactorRandom";
            this.rdoFactorRandom.Size = new System.Drawing.Size(98, 24);
            this.rdoFactorRandom.TabIndex = 10;
            this.rdoFactorRandom.TabStop = true;
            this.rdoFactorRandom.Text = "Random";
            this.rdoFactorRandom.UseVisualStyleBackColor = true;
            this.rdoFactorRandom.CheckedChanged += new System.EventHandler(this.rdoFactorRandom_CheckedChanged);
            // 
            // rdoFactor0
            // 
            this.rdoFactor0.AutoSize = true;
            this.rdoFactor0.Location = new System.Drawing.Point(141, 35);
            this.rdoFactor0.Name = "rdoFactor0";
            this.rdoFactor0.Size = new System.Drawing.Size(40, 24);
            this.rdoFactor0.TabIndex = 12;
            this.rdoFactor0.Text = "0";
            this.rdoFactor0.UseVisualStyleBackColor = true;
            // 
            // rdoFactor2
            // 
            this.rdoFactor2.AutoSize = true;
            this.rdoFactor2.Location = new System.Drawing.Point(88, 64);
            this.rdoFactor2.Name = "rdoFactor2";
            this.rdoFactor2.Size = new System.Drawing.Size(40, 24);
            this.rdoFactor2.TabIndex = 13;
            this.rdoFactor2.Text = "2";
            this.rdoFactor2.UseVisualStyleBackColor = true;
            // 
            // rdoFactor1
            // 
            this.rdoFactor1.AutoSize = true;
            this.rdoFactor1.Location = new System.Drawing.Point(29, 64);
            this.rdoFactor1.Name = "rdoFactor1";
            this.rdoFactor1.Size = new System.Drawing.Size(40, 24);
            this.rdoFactor1.TabIndex = 14;
            this.rdoFactor1.Text = "1";
            this.rdoFactor1.UseVisualStyleBackColor = true;
            // 
            // rdoFactor3
            // 
            this.rdoFactor3.AutoSize = true;
            this.rdoFactor3.Location = new System.Drawing.Point(141, 65);
            this.rdoFactor3.Name = "rdoFactor3";
            this.rdoFactor3.Size = new System.Drawing.Size(40, 24);
            this.rdoFactor3.TabIndex = 15;
            this.rdoFactor3.Text = "3";
            this.rdoFactor3.UseVisualStyleBackColor = true;
            // 
            // rdoFactor4
            // 
            this.rdoFactor4.AutoSize = true;
            this.rdoFactor4.Location = new System.Drawing.Point(29, 98);
            this.rdoFactor4.Name = "rdoFactor4";
            this.rdoFactor4.Size = new System.Drawing.Size(40, 24);
            this.rdoFactor4.TabIndex = 16;
            this.rdoFactor4.Text = "4";
            this.rdoFactor4.UseVisualStyleBackColor = true;
            this.rdoFactor4.CheckedChanged += new System.EventHandler(this.radioButton11_CheckedChanged);
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnStart.Location = new System.Drawing.Point(258, 485);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(136, 37);
            this.btnStart.TabIndex = 17;
            this.btnStart.Text = "Start Training";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // timerQuestion
            // 
            this.timerQuestion.Interval = 1000;
            this.timerQuestion.Tick += new System.EventHandler(this.timerQuestion_Tick);
            // 
            // lblQuestion
            // 
            this.lblQuestion.BackColor = System.Drawing.Color.White;
            this.lblQuestion.Font = new System.Drawing.Font("Comic Sans MS", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.Location = new System.Drawing.Point(38, 70);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(745, 161);
            this.lblQuestion.TabIndex = 19;
            this.lblQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblQuestion.Click += new System.EventHandler(this.lblQuestion_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.Location = new System.Drawing.Point(496, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 30);
            this.label4.TabIndex = 20;
            this.label4.Text = "Correct:";
            // 
            // grpTimer
            // 
            this.grpTimer.BackColor = System.Drawing.Color.RoyalBlue;
            this.grpTimer.Controls.Add(this.lblTimer);
            this.grpTimer.Controls.Add(this.vsbTimer);
            this.grpTimer.Controls.Add(this.rdoTimerBackward);
            this.grpTimer.Controls.Add(this.rdoTimerForward);
            this.grpTimer.Controls.Add(this.rdoTimerOff);
            this.grpTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.grpTimer.ForeColor = System.Drawing.Color.Black;
            this.grpTimer.Location = new System.Drawing.Point(576, 291);
            this.grpTimer.Name = "grpTimer";
            this.grpTimer.Size = new System.Drawing.Size(207, 178);
            this.grpTimer.TabIndex = 7;
            this.grpTimer.TabStop = false;
            this.grpTimer.Text = "Timer";
            // 
            // grpFactor
            // 
            this.grpFactor.BackColor = System.Drawing.Color.RoyalBlue;
            this.grpFactor.Controls.Add(this.rdoFactor9);
            this.grpFactor.Controls.Add(this.rdoFactor7);
            this.grpFactor.Controls.Add(this.rdoFactor8);
            this.grpFactor.Controls.Add(this.rdoFactor6);
            this.grpFactor.Controls.Add(this.rdoFactor5);
            this.grpFactor.Controls.Add(this.rdoFactorRandom);
            this.grpFactor.Controls.Add(this.rdoFactor0);
            this.grpFactor.Controls.Add(this.rdoFactor1);
            this.grpFactor.Controls.Add(this.rdoFactor2);
            this.grpFactor.Controls.Add(this.rdoFactor3);
            this.grpFactor.Controls.Add(this.rdoFactor4);
            this.grpFactor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.grpFactor.ForeColor = System.Drawing.Color.Black;
            this.grpFactor.Location = new System.Drawing.Point(304, 291);
            this.grpFactor.Name = "grpFactor";
            this.grpFactor.Size = new System.Drawing.Size(205, 178);
            this.grpFactor.TabIndex = 8;
            this.grpFactor.TabStop = false;
            this.grpFactor.Text = "Factor";
            this.grpFactor.Enter += new System.EventHandler(this.grpFactor_Enter);
            // 
            // rdoFactor5
            // 
            this.rdoFactor5.AutoSize = true;
            this.rdoFactor5.Location = new System.Drawing.Point(88, 98);
            this.rdoFactor5.Name = "rdoFactor5";
            this.rdoFactor5.Size = new System.Drawing.Size(40, 24);
            this.rdoFactor5.TabIndex = 17;
            this.rdoFactor5.Text = "5";
            this.rdoFactor5.UseVisualStyleBackColor = true;
            // 
            // rdoFactor6
            // 
            this.rdoFactor6.AutoSize = true;
            this.rdoFactor6.Location = new System.Drawing.Point(141, 99);
            this.rdoFactor6.Name = "rdoFactor6";
            this.rdoFactor6.Size = new System.Drawing.Size(40, 24);
            this.rdoFactor6.TabIndex = 18;
            this.rdoFactor6.Text = "6";
            this.rdoFactor6.UseVisualStyleBackColor = true;
            // 
            // rdoFactor7
            // 
            this.rdoFactor7.AutoSize = true;
            this.rdoFactor7.Location = new System.Drawing.Point(29, 130);
            this.rdoFactor7.Name = "rdoFactor7";
            this.rdoFactor7.Size = new System.Drawing.Size(40, 24);
            this.rdoFactor7.TabIndex = 19;
            this.rdoFactor7.Text = "7";
            this.rdoFactor7.UseVisualStyleBackColor = true;
            // 
            // rdoFactor9
            // 
            this.rdoFactor9.AutoSize = true;
            this.rdoFactor9.Location = new System.Drawing.Point(141, 130);
            this.rdoFactor9.Name = "rdoFactor9";
            this.rdoFactor9.Size = new System.Drawing.Size(40, 24);
            this.rdoFactor9.TabIndex = 20;
            this.rdoFactor9.Text = "9";
            this.rdoFactor9.UseVisualStyleBackColor = true;
            this.rdoFactor9.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // rdoFactor8
            // 
            this.rdoFactor8.AutoSize = true;
            this.rdoFactor8.Location = new System.Drawing.Point(88, 130);
            this.rdoFactor8.Name = "rdoFactor8";
            this.rdoFactor8.Size = new System.Drawing.Size(40, 24);
            this.rdoFactor8.TabIndex = 21;
            this.rdoFactor8.Text = "8";
            this.rdoFactor8.UseVisualStyleBackColor = true;
            // 
            // rdoTimerOff
            // 
            this.rdoTimerOff.AutoSize = true;
            this.rdoTimerOff.Checked = true;
            this.rdoTimerOff.ForeColor = System.Drawing.Color.Black;
            this.rdoTimerOff.Location = new System.Drawing.Point(22, 17);
            this.rdoTimerOff.Name = "rdoTimerOff";
            this.rdoTimerOff.Size = new System.Drawing.Size(56, 24);
            this.rdoTimerOff.TabIndex = 22;
            this.rdoTimerOff.TabStop = true;
            this.rdoTimerOff.Text = "Off";
            this.rdoTimerOff.UseVisualStyleBackColor = true;
            this.rdoTimerOff.CheckedChanged += new System.EventHandler(this.rdoTimer_CheckedChanged);
            // 
            // rdoTimerForward
            // 
            this.rdoTimerForward.AutoSize = true;
            this.rdoTimerForward.Location = new System.Drawing.Point(22, 44);
            this.rdoTimerForward.Name = "rdoTimerForward";
            this.rdoTimerForward.Size = new System.Drawing.Size(153, 24);
            this.rdoTimerForward.TabIndex = 23;
            this.rdoTimerForward.Text = "Forward Count";
            this.rdoTimerForward.UseVisualStyleBackColor = true;
            this.rdoTimerForward.CheckedChanged += new System.EventHandler(this.rdoTimer_CheckedChanged);
            // 
            // rdoTimerBackward
            // 
            this.rdoTimerBackward.AutoSize = true;
            this.rdoTimerBackward.Location = new System.Drawing.Point(22, 71);
            this.rdoTimerBackward.Name = "rdoTimerBackward";
            this.rdoTimerBackward.Size = new System.Drawing.Size(167, 24);
            this.rdoTimerBackward.TabIndex = 24;
            this.rdoTimerBackward.Text = "Backward Count";
            this.rdoTimerBackward.UseVisualStyleBackColor = true;
            this.rdoTimerBackward.CheckedChanged += new System.EventHandler(this.rdoTimer_CheckedChanged);
            // 
            // vsbTimer
            // 
            this.vsbTimer.LargeChange = 1;
            this.vsbTimer.Location = new System.Drawing.Point(163, 102);
            this.vsbTimer.Maximum = 60;
            this.vsbTimer.Minimum = 1;
            this.vsbTimer.Name = "vsbTimer";
            this.vsbTimer.Size = new System.Drawing.Size(26, 60);
            this.vsbTimer.TabIndex = 25;
            this.vsbTimer.Value = 1;
            this.vsbTimer.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vsbTimer_Scroll);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnExit.Location = new System.Drawing.Point(445, 485);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(136, 37);
            this.btnExit.TabIndex = 22;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblTimer
            // 
            this.lblTimer.BackColor = System.Drawing.Color.White;
            this.lblTimer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblTimer.ForeColor = System.Drawing.Color.Red;
            this.lblTimer.Location = new System.Drawing.Point(34, 116);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(100, 46);
            this.lblTimer.TabIndex = 23;
            this.lblTimer.Text = "0:00";
            this.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCorrect
            // 
            this.lblCorrect.BackColor = System.Drawing.Color.Red;
            this.lblCorrect.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCorrect.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblCorrect.ForeColor = System.Drawing.Color.Yellow;
            this.lblCorrect.Location = new System.Drawing.Point(628, 18);
            this.lblCorrect.Name = "lblCorrect";
            this.lblCorrect.Size = new System.Drawing.Size(115, 30);
            this.lblCorrect.TabIndex = 23;
            this.lblCorrect.Text = "0";
            this.lblCorrect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormMathGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(843, 543);
            this.Controls.Add(this.lblCorrect);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.grpFactor);
            this.Controls.Add(this.grpTimer);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblQuestion);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.grpType);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblTested);
            this.Controls.Add(this.Tested);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.Name = "FormMathGame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Math Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.FormMathGame_KeyPress);
            this.grpType.ResumeLayout(false);
            this.grpType.PerformLayout();
            this.grpTimer.ResumeLayout(false);
            this.grpTimer.PerformLayout();
            this.grpFactor.ResumeLayout(false);
            this.grpFactor.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label Tested;
        private System.Windows.Forms.Label lblTested;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox grpType;
        private System.Windows.Forms.CheckBox chkSubs;
        private System.Windows.Forms.CheckBox chkMul;
        private System.Windows.Forms.CheckBox chkDiv;
        private System.Windows.Forms.CheckBox chkAdd;
        private System.Windows.Forms.RadioButton rdoFactor3;
        private System.Windows.Forms.RadioButton rdoFactor4;
        private System.Windows.Forms.RadioButton rdoFactorRandom;
        private System.Windows.Forms.RadioButton rdoFactor0;
        private System.Windows.Forms.RadioButton rdoFactor2;
        private System.Windows.Forms.RadioButton rdoFactor1;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Timer timerQuestion;
        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox grpTimer;
        private System.Windows.Forms.GroupBox grpFactor;
        private System.Windows.Forms.RadioButton rdoFactor6;
        private System.Windows.Forms.RadioButton rdoFactor5;
        private System.Windows.Forms.RadioButton rdoFactor7;
        private System.Windows.Forms.RadioButton rdoFactor9;
        private System.Windows.Forms.RadioButton rdoFactor8;
        private System.Windows.Forms.VScrollBar vsbTimer;
        private System.Windows.Forms.RadioButton rdoTimerBackward;
        private System.Windows.Forms.RadioButton rdoTimerForward;
        private System.Windows.Forms.RadioButton rdoTimerOff;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Label lblCorrect;
    }
}

