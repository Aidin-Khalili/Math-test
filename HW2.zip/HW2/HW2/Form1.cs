﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW2
{
    public partial class FormMathGame : Form
    {
        int QuestionTime;

        public FormMathGame()
        {
            InitializeComponent();
        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        Random MyRandom = new Random();
        int Answered, Correct;
        private void btnStart_Click(object sender, EventArgs e)
        {
            int Score;
            string Message = "";
            if (btnStart.Text == "Start Training")
            {
                btnStart.Text = "Stop Training";
                btnExit.Enabled = false;
                Answered = 0;
                Correct = 0;
                lblTested.Text = "0";
                lblCorrect.Text = "0";
                grpTimer.Enabled = false;
                if (!rdoTimerOff.Checked)
                {
                    if (rdoTimerForward.Checked)
                        QuestionTime = 0;
                    else
                        QuestionTime = 30 * vsbTimer.Value;
                    lblTimer.Text = GetTime(QuestionTime);
                    timerQuestion.Enabled = true;
                }
                lblQuestion.Text = GetQuestion();
            }
            else
            {
                grpTimer.Enabled = true;
                timerQuestion.Enabled = false;
                btnStart.Text = "Start Training";
                btnExit.Enabled = true;
                lblQuestion.Text = "";
                if (Answered > 0)
                {
                    Score = (int)(100 * (double)(Correct) /
                    Answered);
                    Message = "The number of questions tried: " +
                    Answered.ToString() + "\r\n";
                    Message += "The number of questions correctly answered: " + Correct.ToString() + " (" + Score.ToString() + "%)" + "\r\n";
                    if (rdoTimerOff.Checked)
                    {
                        Message += "Timer Off";
                    }
                    else
                    {
                        if (rdoTimerBackward.Checked)
                        {
                            QuestionTime =
                            30 * vsbTimer.Value - QuestionTime;
                        }
                        Message += "Total time spent: " +
                        GetTime(QuestionTime) + "\r\n";
                        Message += "Average time every question: " + String.Format("{0:f2}", (double)(QuestionTime) / Answered) + " seconds";
                    }
                    MessageBox.Show(Message, "Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }



        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void grpType_Enter(object sender, EventArgs e)
        {
            int PType, P;
            P = 0;
            do
            {
                PType = MyRandom.Next(4) + 1;
                if (PType == 1 && chkAdd.Checked)
                {
                    // Addition
                    P = PType;
                }
                else if (PType == 2 && chkSubs.Checked)
                {
                    // Substraction
                    P = PType;
                }
                else if (PType == 3 && chkMul.Checked)
                {
                    // Multiplication
                    P = PType;
                }
                else if (PType == 4 && chkDiv.Checked)
                {
                    // Division
                    P = PType;
                }
            } while (P == 0);
        }

        private void grpFactor_Enter(object sender, EventArgs e)
        {

        }

        private int GetFactor(int p)
        {
            if (rdoFactor0.Checked)
                return (0);
            else if (rdoFactor1.Checked)
                return (1);
            else if (rdoFactor2.Checked)
                return (2);
            else if (rdoFactor3.Checked)
                return (3);
            else if (rdoFactor4.Checked)
                return (4);
            else if (rdoFactor5.Checked)
                return (5);
            else if (rdoFactor6.Checked)
                return (6);
            else if (rdoFactor7.Checked)
                return (7);
            else if (rdoFactor8.Checked)
                return (8);
            else if (rdoFactor9.Checked)
                return (9);
            else
            {
                // Random
                if (p == 4)
                    return (MyRandom.Next(9) + 1);
                else
                    return (MyRandom.Next(10));
            }
        }
        private void rdoFactorRandom_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void lblQuestion_Click(object sender, EventArgs e)
        {

        }
        int CorrectAnswer, Digits;
        string Question;
        private string GetQuestion()
        {
            int PType, P, RandValue, Factor;
            P = 0;
            do
            {
                PType = MyRandom.Next(4) + 1;
                if (PType == 1 && chkAdd.Checked)
                {
                    // Addition
                    P = PType;
                    RandValue = MyRandom.Next(10);
                    Factor = GetFactor(1);
                    CorrectAnswer = RandValue + Factor;
                    Question = RandValue.ToString() + " + " +
                    Factor.ToString() + " = ";
                }
                else if (PType == 2 && chkSubs.Checked)
                {
                    // Substraction
                    P = PType;
                    Factor = GetFactor(2);
                    CorrectAnswer = MyRandom.Next(10);
                    RandValue = CorrectAnswer + Factor;
                    Question = RandValue.ToString() + " - " +
                    Factor.ToString() + " = ";
                }
                else if (PType == 3 && chkMul.Checked)
                {
                    // Multiplication
                    P = PType;
                    RandValue = MyRandom.Next(10);
                    Factor = GetFactor(3);
                    CorrectAnswer = RandValue * Factor;
                    Question = RandValue.ToString() + " x " +
                    Factor.ToString() + " = ";
                }
                else if (PType == 4 && chkDiv.Checked)
                {
                    // Division
                    P = PType;
                    Factor = GetFactor(4);
                    CorrectAnswer = MyRandom.Next(10);
                    RandValue = CorrectAnswer * Factor;
                    Question = RandValue.ToString() + " / " +
                    Factor.ToString() + " = ";
                }
            } while (P == 0);
            YourAnswer = "";
            NumberDigitsAnswer = 1;
            this.Focus();
            if (CorrectAnswer < 10)
            {
                Digits = 1;
                return (Question + "?");
            }
            else
            {
                Digits = 2;
                return (Question + "??");
            }
        }

        private void FormMathGame_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (btnStart.Text == "Start Training")
                return;
            // Only allows 0-9 keys
            if (e.KeyChar >= '0' && e.KeyChar <= '9')
            {
                e.Handled = false;
                YourAnswer += e.KeyChar;
                lblQuestion.Text = Question + YourAnswer;
                if (NumberDigitsAnswer != Digits)
                {
                    NumberDigitsAnswer++;
                    lblQuestion.Text += "?";
                    return;
                }
                else
                {
                    Answered++;
                    // Checks answer
                    if (Convert.ToInt32(YourAnswer) ==
                    CorrectAnswer)
                    {
                        Correct++;
                    }
                    lblTested.Text = Answered.ToString();
                    lblTested.Refresh();
                    lblCorrect.Text = Correct.ToString();
                    lblCorrect.Refresh();
                    lblQuestion.Text = GetQuestion();
                    lblQuestion.Refresh();
                }
            }
            else
            {
                e.Handled = true;
            }

        }

        string YourAnswer;
        int NumberDigitsAnswer;
        private void chkType_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox CheckClicked;
            int NumberCheck;
            // Determines which checkbox is selected
            CheckClicked = (CheckBox)sender;
            // Determines how many check boxes are checked
            NumberCheck = 0;
            if (chkAdd.Checked)
                NumberCheck++;
            if (chkSubs.Checked)
                NumberCheck++;
            if (chkMul.Checked)
                NumberCheck++;
            if (chkDiv.Checked)
            {
                NumberCheck++;
                // Ensures that zero is not selected as a factor
                if (rdoFactor0.Checked)
                    rdoFactor1.PerformClick();
                rdoFactor0.Enabled = false;
            }
            else
            {
                rdoFactor0.Enabled = true;
            }
            //If no check box is checked,
            //you need to check the check box that was last selected
            if (NumberCheck == 0)
                CheckClicked.Checked = true;
            this.Focus();
        }
        private void rdoTimer_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoTimerOff.Checked)
            {
                lblTimer.Visible = false;
                vsbTimer.Visible = false;
            }
            else if (rdoTimerForward.Checked)
            {
                QuestionTime = 0;
                lblTimer.Text = GetTime(QuestionTime);
                lblTimer.Visible = true;
                vsbTimer.Visible = false;
            }
            else if (rdoTimerBackward.Checked)
            {
                QuestionTime = 30 * vsbTimer.Value;
                lblTimer.Text = GetTime(QuestionTime);
                lblTimer.Visible = true;
                vsbTimer.Visible = true;
            }
        }
        private string GetTime(int s)
        {
            int min, det;
            string ms, ss;
            min = (int)(s / 60);
            det = s - 60 * min;
            ms = min.ToString();
            ss = det.ToString();
            if (det < 10)
                ss = "0" + ss;
            return (ms + ":" + ss);
        }

        private void vsbTimer_Scroll(object sender, ScrollEventArgs e)
        {
            lblTimer.Text = GetTime(30 * vsbTimer.Value);
            lblTimer.Refresh();
        }


        private void timerQuestion_Tick(object sender,
EventArgs e)
        {
            if (rdoTimerForward.Checked)
            {
                QuestionTime++;
                lblTimer.Text = GetTime(QuestionTime);
                if (QuestionTime >= 1800)
                {
                    btnStart.PerformClick();
                    return;
                }
            }
            else
            {
                QuestionTime--;
                lblTimer.Text = GetTime(QuestionTime);
                if (QuestionTime == 0)
                {
                    btnStart.PerformClick();
                    return;
                }
            }
            lblTimer.Refresh();
        }
    }
}

